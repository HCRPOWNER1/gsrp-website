GSRP PRO WEBSITE — SETUP

FILES
- index.html: the complete responsive website (CSS and JavaScript included).

HOW TO PREVIEW
1. Extract the ZIP.
2. Double-click index.html to open it in Edge or Chrome.

CUSTOMIZE YOUR DISCORD LINK
1. Open index.html in Notepad or VS Code.
2. Find: const DISCORD_INVITE = "https://discord.gg/5UwXWpMymK";
3. Replace the invite with your current GSRP invite.
4. Save and refresh the page.

IMPORTANT
- The player count, online status, and server code show as unavailable until you connect a backend.
- This is intentional: it does not fake live ER:LC data.
- The contact form opens the visitor's email app; it does not store or deliver messages to a website server.
- Do not place ER:LC API keys, Discord bot tokens, passwords, or other secrets in index.html.
- Rules, departments, and news are starter content. Update them to match your actual community.

CONNECT LIVE SERVER DATA LATER
1. Deploy a secure backend that uses your API key on the server side.
2. Make GET /api/server return JSON similar to:
   {"online":true,"playerCount":12,"maxPlayers":40,"serverCode":"ABCDE"}
3. In index.html, change const API_BASE = ""; to your backend base URL, for example:
   const API_BASE = "https://your-backend.example";
4. Make sure the backend allows requests from your website origin (CORS).
5. Never expose your API key in frontend JavaScript.

PUBLISHING
You can host the static index.html on GitHub Pages, Cloudflare Pages, or another static website host.
